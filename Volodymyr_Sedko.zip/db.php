<?php
	if($con == 'con3558'){
		class DB{
			function __construct(){
				if(isset($this->inst)){
					return $this->obj;
				}
				$this->inst = true;
				$this->obj = $this;
			}
			public function connect(){
				$link = new PDO('mysql:host=localhost;dbname=test_php', 'user', 'pass');
				return $link;
			}
			public function createFile(){
				$string = "UID,Name,Age,Email,Phone,Gender\n";
				$link = $this->connect();
				$stmt = $link->query('select * from users');
				//удаляем старый файл
				unlink("$_SERVER[DOCUMENT_ROOT]/users.csv");
				
				while($row = $stmt->fetch(PDO::FETCH_NUM)){
					file_put_contents("$_SERVER[DOCUMENT_ROOT]/users.csv", implode(",", $row)."\n", FILE_APPEND);
				}
			}
		}
	}else{
		header('Location: import');
	}
