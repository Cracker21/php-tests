<?php
	session_start();
	$con = 'con3558';
	require_once 'db.php';
	$dbObj = new DB();
	if(!($link = $dbObj->connect())){
		$_SESSION['msg'] = "failed connection(1)";
		header('Location: import');
		exit();
	}
	if(isset($_POST['clr'])){
		if($link->query('delete from users')){
			unset($_SESSION['result']);
			echo "Data is deleted";
		}
	}else if(isset($_FILES['file']['tmp_name'])){
		require_once 'File.php';
		$file = new File();
		//проверка на ошибки
		$fileHasErrors = $file->hasErrors();
		if($fileHasErrors){
			//вывод ошибок
			$_SESSION['msg'] = $fileHasErrors;
			header('Location: import');
			exit();
		}
		//подготовка запроса
		$stmt = $link->prepare("insert into users values(?, ?, ?, ?, ?, ?) on duplicate key update Name=values(Name),Age=values(Age),Email=values(Email),Phone=values(Phone),Gender=values(Gender)");
		//получение контента файла массивом
		$rows = $file->getContent();
		$_SESSION['result']='<table><tr><td>UID</td><td>Name</td><td>Age</td><td>Email</td><td>Phone</td><td>Gender</td></tr>';
		//проходим по каждой строке и заносим данные в базу
		for($i = 1;$i<count($rows);$i++){
			$stmt->execute([$rows[$i][0], $rows[$i][1], $rows[$i][2], $rows[$i][3], $rows[$i][4], $rows[$i][5]]);
			//запись в сессию для вывода результатов
			$_SESSION['result'].= "<tr><td>". $rows[$i][0]. "</td><td>". $rows[$i][1]."</td><td>". $rows[$i][2]. "</td><td>". $rows[$i][3]. "</td><td>". $rows[$i][4]. "</td><td>". $rows[$i][5]. "</td></tr>";
		}
		$_SESSION['result'].='</table>';
		$_SESSION['msg'] = "file {$_FILES['file']['name']} is uploaded";
		echo $dbObj->createFile();
		header('Location: import');
		exit();
	}else{
		header('Location: import');
	}