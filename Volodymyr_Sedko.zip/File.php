<?php
class File {
	public function getContent(){
		//получаем контент
		$content = trim(file_get_contents($_FILES['file']['tmp_name']));
		//разделяем контент на массив строк
		$rows = explode("\n", $content);
		//получаем двумерный массив строк и полей внутри строк
		for($j = 0;$j<count($rows);$j++){
			$rows[$j] = explode(",",$rows[$j]);
		}
		return $rows;
	}
	public function hasErrors(){
		$error = [];
		if(!is_uploaded_file($_FILES['file']['tmp_name'])){
			$error[]="You didn't select a file";
		}
		//проверка на формат
		if(!preg_match('/^[a-zA-Z0-9\-]+\.csv$/', $_FILES['file']['name'])){
			$error[] = "You can upload only CSV files"; 
		}
		//проверка на размер
		if($_FILES['file']['size'] > 1024){
			$error[] = "File size cannot exceed 1MB";
		}
		$field = $this->getContent();
		//проверка на структуру
		$field = $field[0];
		if(!($field[0] == 'UID'&&$field[1] == 'Name'&&$field[2] == 'Age'&&$field[3] == 'Email'&&$field[4] == 'Phone'&&$field[5] == 'Gender')){
			$error[] = "File structure is not correct";
		}
		return $error[0];
	}
}
