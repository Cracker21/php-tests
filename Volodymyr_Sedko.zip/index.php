<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>File upload</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<script src="script.js"></script>
</head>
<body>
	<h3>File upload</h3>
	<div>
		<label id="resp"></label>
		<?php 
			session_start();
			if(isset($_SESSION['msg'])){
				echo "<p>$_SESSION[msg]</p>";
				unset($_SESSION['msg']);
			}
		?>
		<form enctype="multipart/form-data" action="handler.php" method="POST">
			<input id='fileInp' type="file" name="file">
			<input type="submit" value="Import">
			<a href="results">View results</a>
		</form>
		<input type="button" value="Clear all records" name="clr" onclick="req(event)">
	</div>
</body>
</html>
