<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Результаты</title>
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<script src="script.js"></script>
</head>
<body>
	<div>
		<table>
			<?php
				session_start();
				echo "<h3>Uploaded data:</h3>";
				echo $_SESSION['result'] ?? 'No rows to show';
			?>
		</table>
	</div>
	<a href="users.csv" download><input type="button" name="export" onclick='req(event)' value="Export to CSV"></a>
	<a href="import">Import data</a>
</body>
</html>