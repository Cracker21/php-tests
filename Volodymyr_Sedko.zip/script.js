"use strict"
	function req(e){
		let xhr = new XMLHttpRequest()
		xhr.open('POST', 'handler.php')
		let formData = new FormData();
		formData.append(e.target.name,'data')
		xhr.send(formData)
		xhr.onload = function(){
			resp.innerHTML = xhr.responseText;
		}
	}