<?php
	
	class Account{
		private $num;					//(N)

		function __construct($cardNum){
			$this->num = $cardNum;		//(N)
		}
		public function withdraw(){
			$val = readline('Point a sum to withdraw: ');
			if(is_numeric($val)){
				echo "You have gotten $val UAH";
			}else{
				echo "Incorrect value\r\n";
				$this->withdraw();
			}
		}
		public function topUp(){
			$val = readline('Point a sum to top up: ');
			if(is_numeric($val)){
				echo "You have topped up $val UAH";
			}else{
				echo "Incorrect value\r\n";
				$this->topUp();
			}
		}
		public function showBalance(){
			$bal = rand(0,10000);
			return "Your balance: $bal UAH";
		}
		public function changePin(){
			readline('Enter old pin: ');
			readline('Enter new pin: ');
			return 'PIN was changed';
		}
	}

