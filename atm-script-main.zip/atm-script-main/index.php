<?php
	if(php_sapi_name() == 'cli'){
		
		require 'Service.php';
		require 'Account.php';
	/**

		Some of the defined variables are not involved in this script.
		They are signed by (N) and intended only for real implementation.

	**/
		$cardNum = readline('Card number: ');		//(N)
		$pin = readline('PIN: ');					//(N)

		$account = new Account($cardNum);

		if(Service::pinIsCorrect($account, $pin)){
			Service::route($account, Service::getOption());
		}
	}else{
		echo 'Use CLI to run this script';
	}
