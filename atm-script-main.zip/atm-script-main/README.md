# atm_script

This script is intended only for CLI.

For the launch you need:

1. Clone this repository:

      **git clone https://github.com/Cracker21/atm_script**
  
2. Go to the atm_script folder(in CLI) and run

      php index.php
     
For the use you need just follow instructions on the screen. 
