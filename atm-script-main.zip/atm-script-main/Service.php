<?php

	class Service{
		static function route($account, $option){
			$next = true;
			switch ($option){
				case '1':
					echo $account->showBalance();
					break;
				case '2':
					echo $account->withdraw();
					break;
				case '3':
					echo $account->topUp();
					break;
				case '4':
					echo $account->changePin();
					break;
				case '5':
					//quit option
					$next = false;				
					break;
				default:
					echo 'Incorrect option';
			}
			echo "\r\n";
			//if user doesn't choose quit, offer to use another option shows
			if($next){
				$next = readline('Choose another option (y/n)?  ');
				//if user wants to choose another option, current function begins again
				if($next == 'y'){
					self::route($account, self::getOption());
				}
			}
		}
		static function getOption(){
			echo "Options:\r\n1.Show balance\r\n2.Withdraw\r\n3.Top up\r\n4.Change PIN\r\n5.Quit\r\n";
			$option = readline('Enter option\'s number: ');
			return $option;
		}
		static function pinIsCorrect($account, $pin){
			return true;
		}
	}